module.exports = {
  base: './',
}
