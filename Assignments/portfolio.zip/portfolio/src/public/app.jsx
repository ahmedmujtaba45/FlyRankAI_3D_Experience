const { useState } = React;

const initialValues = {
  name: '',
  email: '',
  timezone: '',
  notifyFrequency: '',
};

function SettingsForm() {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ type: 'idle', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (errors[name]) {
      setErrors((current) => ({ ...current, [name]: '' }));
    }
    if (status.type !== 'idle') {
      setStatus({ type: 'idle', message: '' });
    }
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setIsSubmitting(true);
    setErrors({});
    setStatus({ type: 'idle', message: '' });

    const response = await fetch('/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(values),
    });

    const result = await response.json();
    setIsSubmitting(false);

    if (!result.ok) {
      setErrors(result.errors || {});
      setStatus({ type: 'error', message: 'Please correct the highlighted fields.' });
      return;
    }

    setStatus({ type: 'success', message: result.message });
    setValues(initialValues);
  }

  return (
    <main className="page">
      <h1>Notification settings</h1>
      <p className="intro">Choose how your team updates should be delivered.</p>
      <form onSubmit={handleSubmit} noValidate>
        <label htmlFor="name">Display name</label>
        <input id="name" name="name" type="text" value={values.name} onChange={handleChange} autoComplete="name" required aria-describedby="name-error" />
        <p className="error" id="name-error" role="alert">{errors.name || ''}</p>

        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" value={values.email} onChange={handleChange} autoComplete="email" required aria-describedby="email-error" />
        <p className="error" id="email-error" role="alert">{errors.email || ''}</p>

        <label htmlFor="timezone">Timezone</label>
        <select id="timezone" name="timezone" value={values.timezone} onChange={handleChange} required aria-describedby="timezone-error">
          <option value="">Select timezone</option>
          <option value="UTC">UTC</option>
          <option value="America/New_York">America/New_York</option>
          <option value="Europe/London">Europe/London</option>
        </select>
        <p className="error" id="timezone-error" role="alert">{errors.timezone || ''}</p>

        <label htmlFor="notifyFrequency">Notification frequency</label>
        <select id="notifyFrequency" name="notifyFrequency" value={values.notifyFrequency} onChange={handleChange} required aria-describedby="notifyFrequency-error">
          <option value="">Select frequency</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
        <p className="error" id="notifyFrequency-error" role="alert">{errors.notifyFrequency || ''}</p>

        {status.message ? (
          <p className={`status ${status.type}`} role="status">{status.message}</p>
        ) : null}

        <button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Saving…' : 'Save settings'}</button>
      </form>
    </main>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<SettingsForm />);
